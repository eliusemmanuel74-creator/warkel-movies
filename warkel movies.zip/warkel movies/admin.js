console.log("ADMIN.JS IMEFUNGUKA");

const firebaseConfig = {
  apiKey: "AIzaSyDEqZX4tJ4Y8LnyuDCal_6OyF6bvEW5Dpk",
  authDomain: "warkel-movies.firebaseapp.com",
  projectId: "warkel-movies",
  storageBucket: "warkel-movies.firebasestorage.app",
  messagingSenderId: "1087357366041",
  appId: "1:1087357366041:web:b62ba5e42da9e0792f1f88"
};

firebase.initializeApp(firebaseConfig);

console.log("FIREBASE IMEFUNGUKA");

const auth = firebase.auth();

document
  .getElementById("loginForm")
  .addEventListener("submit", function(e) {

    e.preventDefault();

    const email =
      document.getElementById("adminEmail").value.trim();

    const password =
      document.getElementById("adminPassword").value;

    const message =
      document.getElementById("loginMessage");

    message.textContent = "⏳ Inajaribu login...";
    message.style.color = "white";

    auth.signInWithEmailAndPassword(email, password)

      .then(function(result) {

        console.log("LOGIN SUCCESS");

        message.textContent =
          "✅ Login imefanikiwa!";

        message.style.color = "#00ff88";

        setTimeout(function() {
          window.location.href = "dashboard.html";
        }, 800);

      })

      .catch(function(error) {

        console.error(error);

        message.textContent =
          "❌ " + error.code;

        message.style.color = "#ff4444";

      });

  });